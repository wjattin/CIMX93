
<?php include("secure.php");?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <?php include("includes/head.php"); ?>
  </head>
  <body>
    <?php include("includes/navbar.php"); ?>
    <div class="container">
<?php
include("includes/database.php");

$sql = "SELECT * FROM `users` WHERE false = false";

$result = $mysqli->query($sql);
echo $result->num_rows.' found';
while($user = $result->fetch_array(MYSQLI_ASSOC)) {
  echo $user['first_name']." ".$user['last_name']."<br>";
}
?>
<h1>Current user</h1>

<?php
//$sql = "SELECT * FROM `users` WHERE `email` = '". $_COOKIE['user'] ."'";
$sql = "SELECT * FROM `users` JOIN `profile` ON users.id = profile.user_id WHERE `email` = '". $_COOKIE['user'] ."'";
echo $sql;
$result = $mysqli->query($sql);
echo $result->num_rows.' found';
//if we have 1 user
if($result->num_rows) {
  ?>
  <a href="profile.php">Edit Profile</a>
  <?php
  }
  else {
    ?>
    <p>It seems you don't have a profile ...<a href="profile.php">Create Profile</a></p>
    <?php
  }


while($user = $result->fetch_array(MYSQLI_ASSOC)) {
  echo "<br>".$user['first_name']." ".$user['last_name']."<br>".$user['id'];
}

//var_dump($result->fetch_array(MYSQLI_ASSOC));



?>
<br>
<a href="logout.php">Log out</a>
</div>
<?php include("includes/scripts.php"); ?>

</body>
</html>