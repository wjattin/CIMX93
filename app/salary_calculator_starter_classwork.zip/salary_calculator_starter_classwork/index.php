<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Salary Calculator</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h1>Salary Calculator</h1>
    <?php
    // Define variables: the assignment of values to a variable
    $hourlyRate = 0.00;
    $hoursWorked = 0;
    $rateMultiplier = 1.5;
    $commissionRate = 0.0;
    $grossSales = 0.00;
    $bonus = 0;


    // $_GET is a built-in php variable which gets the values of a query string. i.e ?name=william&age=22
    // isset() is a php function which tests if a variable exists.
    // Conditional logic: make the program "do something" if a condition is met.
    // Here we'll set the values of our variables if they exist in the query. NOTE: IT DOESN'T CHECK IF IT HAS A VALUE...ONLY IF IT EXISTS
    if( isset($_GET["hourly_rate"]) ){
      $hourlyRate = $_GET["hourly_rate"];
    }

    if( isset($_GET["hours_worked"]) ){
      $hoursWorked = $_GET["hours_worked"];
    }

    if( isset($_GET["rate_multiplier"]) ){
      $rateMultiplier = $_GET["rate_multiplier"];
    }

    if( isset($_GET["commission_rate"]) ){
      $commissionRate = $_GET["commission_rate"];
    }

    if( isset($_GET["gross_sales"]) ){
      $grossSales = $_GET["gross_sales"];
    }

        ?>
<!--

If syntax examples:
<?php
if('somecondition'):
//do something
endif;
?>

<?php
if('somecondition'){
//do something
}
?>

-->
<!-- Form -->
<form class="" action="index.php" method="get">
  <p>
  <label for="hourly_rate">Hourly Rate:</label>
  <!-- Note that:
    <?php echo $hourlyRate; ?>
    and
    <?=$hourlyRate?>
    can be used interchangeably
  -->
  <input type="text" name="hourly_rate" value="<?php echo $hourlyRate; ?>">
  </p>
  <p>
  <label for="hours_worked">Hours Worked:</label>
  <input type="text" name="hours_worked" value="<?php echo $hoursWorked; ?>">
  </p>
  <!-- Additional fields -->
  <p>
  <label for="rate_multiplier">Rate Multiplier:</label>

  <select class="" name="rate_multiplier">
    <?php if(isset($_GET["rate_multiplier"])): ?>
      <option value="<?php echo $_GET["rate_multiplier"]; ?>">
        <?php echo $_GET["rate_multiplier"]; ?>
      </option>
    <?php endif; ?>

    <option value="1.0">1.0</option>
    <option value="1.5">1.5</option>
    <option value="2.0">2.0</option>
  </select>
  </p>

  <p>
  <label for="commission_rate">Commission Rate:</label>
  <input type="text" name="commission_rate" value="<?php echo $commissionRate; ?>">
  </p>

  <p>
  <label for="gross_sales">Gross Sales:</label>
  <input type="text" name="gross_sales" value="<?php echo $grossSales; ?>">
  </p>
  <p class="submit">
  <input class="btn" type="submit" name="submit" value="Calculate">
  </p>
</form>
<!-- Totals -->
<?php

$commissionMessage = "";

$holidayRate = $hourlyRate * $rateMultiplier;

$holidayPay = $holidayRate * $hoursWorked;

//Comparing variables and other values. See working with variables slides or class notebook
if ($hoursWorked >= 20) {
  $commission = $grossSales * $commissionRate;
  $commissionMessage = "Great Job!";
} else {
  $commission = 0;
  $commissionMessage = "Need to work more than 20 hours to get commission.";
}

$salary = $holidayPay + $commission;
?>
<hr>
<br>
<!-- Combine html and php -->
<div class="totals">
  <h2>Totals</h2>
  <p><strong>Holiday Pay :</strong><span>$<?=$holidayPay;  ?></span> </p>
  <p><strong>Commission:</strong> <span>$<?=$commission?> <?=$commissionMessage?></span></p>
  <p><strong>Salary :</strong> <span>$<?=$salary?></span></p> <!-- ?= shotcut for print or echo -->
  <!-- anything here is a comment -->
</div>
  </body>
</html>


