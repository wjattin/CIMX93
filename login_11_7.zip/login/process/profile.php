<?php
//
// Store the variables from the POST request
$address = $_POST['address'];
$address_2 = $_POST['address_2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$user_id = 0;

include("../includes/database.php");

$sql = "SELECT * FROM `users` WHERE `email` = '".$_COOKIE['user']."'";

$result = $mysqli->query($sql);
echo $result->num_rows.' found';
while($user = $result->fetch_array(MYSQLI_ASSOC)) {
  echo $user['email']." ".$user['id']."<br>";
  $user_id = $user['id'];
}

$sql = "SELECT * FROM `users` JOIN `profile` ON users.id = profile.user_id WHERE `email` = '". $_COOKIE['user'] ."'";

$result = $mysqli->query($sql);

echo $result->num_rows.' found';
if($result->num_rows) {
  //this is going to be an update
  $sql = "UPDATE `profile` SET `address` = '$address', `address_2` = '$address_2', `city` = '$city', `state` = '$state', `zip` = '$zip' WHERE `profile`.`id` = $user_id";
} else {
  //new record
  // First, we need a query...Paste the query we copied from phpmyadmin and replace the values with our variables
  $sql = "INSERT INTO `profile` (`id`, `address`, `address_2`, `city`, `state`, `zip`, `user_id`) VALUES (NULL, '$address', '$address_2', '$city', '$state', '$zip', '$user_id')";
}


// Print the sql to debug
print($sql);
//die();
// https://www.php.net/manual/en/mysqli.query.php
/* Select queries return a result. On insert, returns 1 or 0 (TRUE or FALSE)  */

if ( $result = $mysqli->query($sql) ) {
 echo " we were able to create the profile for ". $_COOKIE['user'];
 header("location: ../profile.php?update=true");
} else {
  echo "something went wrong ";
  echo $mysqli->error;
}
// close the connection once we are finished with our queries
$mysqli->close();
?>
