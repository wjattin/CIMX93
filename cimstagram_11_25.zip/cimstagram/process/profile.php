<?php
//
// Store the variables from the POST request
$address = $_POST['address'];
$address_2 = $_POST['address_2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$user_id = 0;

// lets process the image file
if(isset($_FILES["profile_image"]["name"])){
// Specify the folder where we are uploading our image to
$target_dir = "../profile_images/";
//set our starting image name. We will change this in a bit..
$target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
// Get the file extension
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
//generate a random image name (we will use it to upload and get the file name to insert in out database)
$randomFileName = microtime() .".". $imageFileType;
//combine the file name with our upload folder
$target_file = $target_dir . $randomFileName;
$uploadOk = 1;
$check = getimagesize($_FILES["profile_image"]["tmp_name"]);
if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
} else {
    echo "File is not an image.";
    $uploadOk = 0;
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["profile_image"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["profile_image"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}

include("../includes/db_class.php");

$db = new database();
//Since we need to associate this record with another, we need to get the record id first (user_id)
$columns = "*";
$tablename = "users";
$filters = ["email" => $_COOKIE['user']];
$result = $db->query($columns,$tablename,$filters);

while($user = $result->fetch_array(MYSQLI_ASSOC)) {
  echo $user['email']." ".$user['id']."<br>";
  $user_id = $user['id'];
}
// Our insert parameters
$columns = "user_id";
$tablename = "profile";
$filters = ["user_id" => $user_id];
$result = $db->query($columns,$tablename,$filters);



$tablename = "profile";
$columndata = [ 'address' => $address,
                'address_2' => $address_2,
                'city' => $city,
                'state' => $state,
                'zip' => $zip,
                ];
// Here we can check if there was an upload and add it to columndata
if($uploadOk) {
  $columndata['profile_image'] = $randomFileName;
}

if(isset($result->num_rows) && ($result->num_rows == 0)){
  echo "will do insert<br>";
$result = $db->insert($tablename,$columndata);
} else {
  //we update
  echo "will do update<br>";
  $result = $db->update($columndata,$tablename,$filters);
}
if ( $result ) {
 echo " we were able to create the profile for ". $_COOKIE['user'];
 header("location: ../profile.php?update=true");
} else {
  echo "something went wrong ";
}

?>
