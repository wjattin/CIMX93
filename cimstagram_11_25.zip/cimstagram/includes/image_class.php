<?php
  //Implementing the file upload script with a class because we will use this many times.
class uploadImage($file) {

  $target_dir = "../post_images/";
  $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
}

?>
