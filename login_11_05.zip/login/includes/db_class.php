<?php

class database {
  public $mysqli;
/*
* sets our initial object
*/
  public function __construct(){
    echo "inside db class<br>";

    // Initialize the PHP MySql library
    $this->mysqli = mysqli_init();
    // Error checking syntax
    if (!$this->mysqli) {
        die('mysqli_init failed');
    }
    // More error checking.
    if (!$this->mysqli->options(MYSQLI_INIT_COMMAND, 'SET AUTOCOMMIT = 1')) {
        die('Setting MYSQLI_INIT_COMMAND failed');
    }
    // If it takes more than 5 seconds to connect, we have a problem
    if (!$this->mysqli->options(MYSQLI_OPT_CONNECT_TIMEOUT, 5)) {
        die('Setting MYSQLI_OPT_CONNECT_TIMEOUT failed');
    }
    // connect syntax $mysqli->real_connect('host address', 'username', 'password', 'database name');
    // In the following connection, the password is empty because of the default xampp installation
    if (!$this->mysqli->real_connect('localhost', 'root', '', 'cimstagram')) {
        die('Connect Error (' . mysqli_connect_errno() . ') '
                . mysqli_connect_error());
    }

    echo 'Success... ' . $this->mysqli->host_info . "\n<br>";
  }
  /*
  * we can create custom functions
  */
  public function query($columns,$tablename,$filters){
    $where = "";
    $count = 0;
    //$filters is an array. we count the array to see if it has values
    if(count($filters) > 0) {
      $where = "WHERE ";
      foreach($filters as $key => $value){
        if($count > 0) {
          $combine = " AND";
        } else {
          $combine = "";
        }
        $where .= "$combine $key LIKE '$value' ";
        $count++;
      }
    }
    $sql = "SELECT $columns FROM $tablename $where";

    return $this->mysqli->query($sql);

  }

  public function insert($tablename,$filters){
    $sql = "INSERT INTO $tablename (`id`, `address`, `address_2`, `city`, `state`, `zip`, `user_id`) VALUES (NULL, '$address', '$address_2', '$city', '$state', '$zip', '$user_id')";
  }
}


?>