<?php

class database {

  public function __construct(){

  }
}


?>