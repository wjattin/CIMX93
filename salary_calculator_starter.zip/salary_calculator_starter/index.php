<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Retro Salary Calculator</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h1>Salary Calculator</h1>
    <?php
    $hourlyRate = 0.00;
    $hoursWorked = 0;
    $rateMultiplier = 1.5;
    $commissionRate = 0.0;
    $grossSales = 0.00;
    $bonus = 0;
    ?>

<!-- Form -->
<form class="" action="index.php" method="get">
  <p>
  <label for="hourly_rate">Hourly Rate:</label>
  <input type="text" name="hourly_rate" value="">
  </p>
  <p>
  <label for="hours_worked">Hours Worked:</label>
  <input type="text" name="hours_worked" value="">
  </p>

  <p class="submit">
  <input class="btn" type="submit" name="submit" value="Calculate">
  </p>
</form>
<!-- Totals -->
<?php

$holidayRate = $hourlyRate * $rateMultiplier;

$holidayPay = $holidayRate * $hoursWorked;

$salary = $holidayPay + $commission;
?>
<hr>
<br>
<!-- Combine html and php -->
<div class="totals">
  <h2>Totals</h2>
  <p><strong>Holiday Pay :</strong><span>$<?=$holidayPay;  ?></span> </p>
  <p><strong>Commission:</strong> <span>$<?=$commission?></span></p>
  <p><strong>Salary :</strong> <span>$<?=$salary?></span></p> <!-- ?= shotcut for print or echo -->
  <!-- anything here is a comment -->
</div>
  </body>
</html>


